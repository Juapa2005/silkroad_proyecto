import java.awt.Color;

/**
 * Barra de progreso para mostrar ganancias relativas a la ganancia máxima posible
 * Se visualiza como una barra sin números como se especifica en los requisitos
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class ProgressBar {
    private Canvas canvas;
    private java.awt.Rectangle backgroundBar;
    private java.awt.Rectangle progressBar;
    private int currentProfit;
    private int maxProfit;
    private String uniqueId;
    
    /**
     * Constructor para ProgressBar
     * @param canvas Canvas en el que dibujar
     */
    public ProgressBar(Canvas canvas) {
        this.canvas = canvas;
        this.backgroundBar = new java.awt.Rectangle(50, 20, 300, 30);
        this.progressBar = new java.awt.Rectangle(50, 20, 0, 30);
        this.currentProfit = 0;
        this.maxProfit = 0;
        this.uniqueId = "progressbar_" + System.currentTimeMillis();
    }
    
    /**
     * Actualiza la barra de progreso con nuevos valores
     * @param currentProfit Ganancia actual obtenida
     * @param maxProfit Ganancia máxima posible
     */
    public void update(int currentProfit, int maxProfit) {
        this.currentProfit = Math.max(0, currentProfit); // No permitir ganancias negativas en la visualización
        this.maxProfit = Math.max(1, maxProfit); // Evitar división por cero
        
        // Calcular ancho del progreso
        double ratio = (double) this.currentProfit / this.maxProfit;
        int progressWidth = (int) (ratio * 300);
        progressWidth = Math.max(0, Math.min(300, progressWidth)); // Limitar a los límites
        
        this.progressBar = new java.awt.Rectangle(50, 20, progressWidth, 30);
        drawProgressBar();
    }
    
    /**
     * Dibuja la barra de progreso en el canvas
     */
    private void drawProgressBar() {
        try {
            // Limpiar barras anteriores usando IDs únicos
            canvas.erase(uniqueId + "_background");
            canvas.erase(uniqueId + "_progress");
            canvas.erase(uniqueId + "_border");
            
            // Dibujar fondo (barra vacía) - color gris claro
            canvas.draw(uniqueId + "_background", "white", backgroundBar);
            
            // Dibujar progreso (porción llena)
            if (progressBar.width > 0) {
                canvas.draw(uniqueId + "_progress", "green", progressBar);
            }
            
            // Dibujar borde
            java.awt.Rectangle border = new java.awt.Rectangle(49, 19, 302, 32);
            canvas.draw(uniqueId + "_border", "blue", border);
            
        } catch (Exception e) {
            // Canvas no está listo para dibujar, ignorar silenciosamente
        }
    }
    
    /**
     * Obtiene la ganancia actual
     * @return Valor de ganancia actual
     */
    public int getCurrentProfit() {
        return currentProfit;
    }
    
    /**
     * Obtiene la ganancia máxima
     * @return Valor de ganancia máxima posible
     */
    public int getMaxProfit() {
        return maxProfit;
    }
}