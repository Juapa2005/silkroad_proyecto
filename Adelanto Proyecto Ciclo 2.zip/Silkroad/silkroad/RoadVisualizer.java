import java.awt.Color;
import java.awt.Polygon;
import java.util.List;
import java.util.ArrayList;

/**
 * Visualiza la Ruta de Seda como una espiral cuadrada
 * Maneja el posicionamiento y dibujado de tiendas y robots
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class RoadVisualizer {
    private Canvas canvas;
    private int roadLength;
    private int cellSize;
    private int startX, startY;
    private List<Point> roadPoints;
    
    /**
     * Constructor para RoadVisualizer
     * @param canvas Canvas en el que dibujar
     * @param roadLength Longitud de la ruta
     */
    public RoadVisualizer(Canvas canvas, int roadLength) {
        this.canvas = canvas;
        this.roadLength = roadLength;
        this.cellSize = 20;
        this.startX = 400;
        this.startY = 300;
        this.roadPoints = new ArrayList<>();
        
        generateSpiralPoints();
    }
    
    /**
     * Genera puntos para la ruta en espiral cuadrada
     */
    private void generateSpiralPoints() {
        roadPoints.clear();
        
        int x = startX;
        int y = startY;
        int direction = 0; // 0=derecha, 1=arriba, 2=izquierda, 3=abajo
        int steps = 1;
        int stepCount = 0;
        int changeCount = 0;
        
        roadPoints.add(new Point(x, y));
        
        for (int i = 1; i < Math.min(roadLength, 1000); i++) {
            // Mover en la dirección actual
            switch (direction) {
                case 0: x += cellSize; break; // derecha
                case 1: y -= cellSize; break; // arriba
                case 2: x -= cellSize; break; // izquierda
                case 3: y += cellSize; break; // abajo
            }
            
            roadPoints.add(new Point(x, y));
            stepCount++;
            
            // Verificar si necesitamos cambiar dirección
            if (stepCount == steps) {
                direction = (direction + 1) % 4;
                stepCount = 0;
                changeCount++;
                
                // Incrementar pasos cada dos cambios de dirección
                if (changeCount % 2 == 0) {
                    steps++;
                }
            }
        }
    }
    
    /**
     * Dibuja la ruta en el canvas
     */
    public void drawRoad() {
        try {
            for (int i = 0; i < roadPoints.size(); i++) {
                Point p = roadPoints.get(i);
                java.awt.Rectangle roadCell = new java.awt.Rectangle(p.x - cellSize/2, p.y - cellSize/2, 
                                                 cellSize, cellSize);
                canvas.draw("road_" + i, "white", roadCell);
                
                // Dibujar borde de la ruta
                java.awt.Rectangle border = new java.awt.Rectangle(p.x - cellSize/2 - 1, p.y - cellSize/2 - 1, 
                                               cellSize + 2, cellSize + 2);
                canvas.draw("road_border_" + i, "black", border);
            }
        } catch (Exception e) {
            // Canvas no está listo para dibujar, ignorar silenciosamente
        }
    }
    
    /**
     * Añade una tienda a la visualización
     * @param store Tienda a añadir
     */
    public void addStore(Store store) {
        Point position = getPositionForLocation(store.getLocation());
        if (position != null) {
            java.awt.Rectangle storeRect = new java.awt.Rectangle(position.x - cellSize/3, 
                                              position.y - cellSize/3, 
                                              cellSize*2/3, cellSize*2/3);
            String color = colorToString(store.getColor());
            canvas.draw("store_" + store.getLocation(), color, storeRect);
        }
    }
    
    /**
     * Elimina una tienda de la visualización
     * @param store Tienda a eliminar
     */
    public void removeStore(Store store) {
        canvas.erase("store_" + store.getLocation());
    }
    
    /**
     * Actualiza la visualización de una tienda (ej. cuando es vaciada)
     * @param store Tienda a actualizar
     */
    public void updateStore(Store store) {
        Point position = getPositionForLocation(store.getLocation());
        if (position != null) {
            java.awt.Rectangle storeRect = new java.awt.Rectangle(position.x - cellSize/3, 
                                              position.y - cellSize/3, 
                                              cellSize*2/3, cellSize*2/3);
            
            String color;
            if (store.isEmpty()) {
                color = "gray"; // Las tiendas vaciadas se ven diferentes
            } else {
                color = colorToString(store.getColor());
            }
            
            canvas.draw("store_" + store.getLocation(), color, storeRect);
        }
    }
    
    /**
     * Añade un robot (triángulo) a la visualización
     * @param robot Robot a añadir
     */
    public void addRobot(Robot robot) {
        Point position = getPositionForLocation(robot.getCurrentLocation());
        if (position != null) {
            // Crear triángulo para el robot
            int[] xpoints = { position.x, position.x - cellSize/4, position.x + cellSize/4 };
            int[] ypoints = { position.y - cellSize/4, position.y + cellSize/4, position.y + cellSize/4 };
            Polygon robotTriangle = new Polygon(xpoints, ypoints, 3);
            
            String color = colorToString(robot.getColor());
            canvas.draw("robot_" + robot.getStartLocation(), color, robotTriangle);
        }
    }
    
    /**
     * Elimina un robot de la visualización
     * @param robot Robot a eliminar
     */
    public void removeRobot(Robot robot) {
        canvas.erase("robot_" + robot.getStartLocation());
    }
    
    /**
     * Actualiza la visualización de un robot (ej. cuando se mueve o parpadea)
     * @param robot Robot a actualizar
     */
    public void updateRobot(Robot robot) {
        Point position = getPositionForLocation(robot.getCurrentLocation());
        if (position != null) {
            // Crear triángulo para el robot
            int[] xpoints = { position.x, position.x - cellSize/4, position.x + cellSize/4 };
            int[] ypoints = { position.y - cellSize/4, position.y + cellSize/4, position.y + cellSize/4 };
            Polygon robotTriangle = new Polygon(xpoints, ypoints, 3);
            
            String color = colorToString(robot.getColor());
            if (robot.isBlinking()) {
                // Los robots que parpadean se resaltan en amarillo
                color = "yellow";
            }
            
            canvas.draw("robot_" + robot.getStartLocation(), color, robotTriangle);
        }
    }
    
    /**
     * Dibuja todas las tiendas y robots
     * @param stores Lista de tiendas
     * @param robots Lista de robots
     */
    public void drawAll(List<Store> stores, List<Robot> robots) {
        // Dibujar todas las tiendas
        for (Store store : stores) {
            addStore(store);
        }
        
        // Dibujar todos los robots
        for (Robot robot : robots) {
            addRobot(robot);
        }
    }
    
    /**
     * Actualiza todas las tiendas
     * @param stores Lista de tiendas a actualizar
     */
    public void updateAllStores(List<Store> stores) {
        for (Store store : stores) {
            updateStore(store);
        }
    }
    
    /**
     * Actualiza todos los robots
     * @param robots Lista de robots a actualizar
     */
    public void updateAllRobots(List<Robot> robots) {
        for (Robot robot : robots) {
            updateRobot(robot);
        }
    }
    
    /**
     * Actualiza todo con las listas proporcionadas
     * @param stores Lista de tiendas
     * @param robots Lista de robots
     */
    public void updateAll(List<Store> stores, List<Robot> robots) {
        updateAllStores(stores);
        updateAllRobots(robots);
    }
    
    /**
     * Obtiene la posición para una ubicación de ruta dada
     * @param location Ubicación en la ruta (0 a roadLength-1)
     * @return Point representando la posición, o null si es inválida
     */
    private Point getPositionForLocation(int location) {
        if (location >= 0 && location < roadPoints.size()) {
            return roadPoints.get(location);
        }
        return null;
    }
    
    /**
     * Convierte Color a representación string (sin negro)
     * @param color Objeto Color
     * @return Representación string del color
     */
    private String colorToString(Color color) {
        if (color.equals(Color.RED)) return "red";
        else if (color.equals(Color.BLUE)) return "blue";
        else if (color.equals(Color.GREEN)) return "green";
        else if (color.equals(Color.YELLOW)) return "yellow";
        else if (color.equals(Color.ORANGE)) return "orange";
        else if (color.equals(Color.MAGENTA)) return "magenta";
        else if (color.equals(Color.CYAN)) return "cyan";
        else if (color.equals(Color.PINK)) return "pink";
        else if (color.equals(Color.GRAY)) return "gray";
        else return "red"; // Por defecto rojo en lugar de negro
    }
    
    /**
     * Clase Point simple para coordenadas
     */
    private class Point {
        public int x, y;
        
        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}