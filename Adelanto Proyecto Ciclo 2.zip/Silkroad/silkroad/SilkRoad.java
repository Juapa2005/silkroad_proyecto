import java.util.*;
import java.awt.Color;

/**
 * Simulador de la Ruta de Seda basado en el Problem J de ICPC 2024
 * Simula robots que recolectan tenges de tiendas a lo largo de una ruta
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class SilkRoad {
    private int length;
    private Canvas canvas;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private ArrayList<Integer[]> days; // Para almacenar secuencias de días
    private int totalProfit;
    private int maxPossibleProfit;
    private boolean isVisible;
    private ProgressBar profitBar;
    private RoadVisualizer roadVisualizer;
    
    /**
     * Constructor para el simulador SilkRoad
     * @param length La longitud de la ruta de seda
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.days = new ArrayList<>();
        this.totalProfit = 0;
        this.maxPossibleProfit = 0;
        this.isVisible = false;
        this.canvas = new Canvas("Simulador Ruta de Seda", 800, 600, Color.WHITE, true);
        this.profitBar = new ProgressBar(canvas);
        this.roadVisualizer = new RoadVisualizer(canvas, length);
    }
    
    /**
     * Constructor para SilkRoad con secuencia de días del problema
     * @param days Array de datos de días [tipo, ubicación, tenges]
     */
    public SilkRoad(Integer[][] days) {
        this(1000); // Longitud por defecto grande
        this.days = new ArrayList<>(Arrays.asList(days));
        processDaySequence();
    }
    
    /**
     * Coloca una tienda en la ubicación especificada con tenges dados
     * @param location Posición en la ruta
     * @param tenges Cantidad de dinero en la tienda
     */
    public void placeStore(int location, int tenges) {
        if (location < 0 || location > length) {
            if (isVisible) {
                showMessage("Ubicación inválida: La tienda debe colocarse dentro de los límites de la ruta (0-" + length + ")");
            }
            return;
        }
        
        // Verificar si la ubicación ya está ocupada por una tienda
        for (Store store : stores) {
            if (store.getLocation() == location) {
                if (isVisible) {
                    showMessage("Ubicación ya ocupada por una tienda");
                }
                return;
            }
        }
        
        Store newStore = new Store(location, tenges, getNextStoreColor());
        stores.add(newStore);
        resupplyStores();
        updateMaxPossibleProfit();
        
        if (isVisible) {
            roadVisualizer.addStore(newStore);
            profitBar.update(totalProfit, maxPossibleProfit);
        }
    }
    
    /**
     * Elimina la tienda en la ubicación especificada
     * @param location Posición de la tienda a eliminar
     */
    public void removeStore(int location) {
        Store toRemove = null;
        for (Store store : stores) {
            if (store.getLocation() == location) {
                toRemove = store;
                break;
            }
        }
        
        if (toRemove == null) {
            if (isVisible) {
                showMessage("No se encontró tienda en la ubicación " + location);
            }
            return;
        }
        
        stores.remove(toRemove);
        resupplyStores();
        updateMaxPossibleProfit();
        
        if (isVisible) {
            roadVisualizer.removeStore(toRemove);
            profitBar.update(totalProfit, maxPossibleProfit);
        }
    }
    
    /**
     * Coloca un robot en la ubicación especificada
     * @param location Posición inicial del robot
     */
    public void placeRobot(int location) {
        if (location < 0 || location > length) {
            if (isVisible) {
                showMessage("Ubicación inválida: El robot debe colocarse dentro de los límites de la ruta (0-" + length + ")");
            }
            return;
        }
        
        // Verificar si la ubicación ya está ocupada por la posición inicial de otro robot
        for (Robot robot : robots) {
            if (robot.getStartLocation() == location) {
                if (isVisible) {
                    showMessage("Ubicación inicial ya ocupada por otro robot");
                }
                return;
            }
        }
        
        Robot newRobot = new Robot(location, getNextRobotColor());
        robots.add(newRobot);
        returnRobots();
        
        if (isVisible) {
            roadVisualizer.addRobot(newRobot);
            updateRobotBlinking();
        }
    }
    
    /**
     * Elimina el robot en la ubicación especificada
     * @param location Posición inicial del robot a eliminar
     */
    public void removeRobot(int location) {
        Robot toRemove = null;
        for (Robot robot : robots) {
            if (robot.getStartLocation() == location) {
                toRemove = robot;
                break;
            }
        }
        
        if (toRemove == null) {
            if (isVisible) {
                showMessage("No se encontró robot con ubicación inicial " + location);
            }
            return;
        }
        
        robots.remove(toRemove);
        returnRobots();
        
        if (isVisible) {
            roadVisualizer.removeRobot(toRemove);
            updateRobotBlinking();
        }
    }
    
    /**
     * Mueve un robot a la ubicación y distancia especificadas
     * @param location Ubicación actual del robot
     * @param meters Distancia a mover
     */
    public void moveRobot(int location, int meters) {
        Robot robotToMove = null;
        for (Robot robot : robots) {
            if (robot.getCurrentLocation() == location) {
                robotToMove = robot;
                break;
            }
        }
        
        if (robotToMove == null) {
            if (isVisible) {
                showMessage("No se encontró robot en la ubicación " + location);
            }
            return;
        }
        
        int newLocation = location + meters;
        if (newLocation < 0 || newLocation > length) {
            if (isVisible) {
                showMessage("El robot no puede moverse fuera de los límites de la ruta");
            }
            return;
        }
        
        robotToMove.move(newLocation, meters);
        
        // Verificar si el robot llegó a una tienda
        Store storeAtLocation = null;
        for (Store store : stores) {
            if (store.getLocation() == newLocation && !store.isEmpty()) {
                storeAtLocation = store;
                break;
            }
        }
        
        if (storeAtLocation != null) {
            int profit = storeAtLocation.getCurrentTenges() - Math.abs(meters);
            robotToMove.addProfit(profit);
            totalProfit += profit;
            
            // Solo vaciar la tienda si la ganancia fue positiva
            if (profit > 0) {
                storeAtLocation.empty();
                storeAtLocation.incrementEmptiedCount();
                
                if (isVisible) {
                    roadVisualizer.updateStore(storeAtLocation);
                }
            }
        }
        
        if (isVisible) {
            roadVisualizer.updateRobot(robotToMove);
            profitBar.update(totalProfit, maxPossibleProfit);
            updateRobotBlinking();
        }
    }
    
    /**
     * Mueve los robots automáticamente para maximizar las ganancias
     */
    public void moveRobots() {
        // Implementar algoritmo greedy para el movimiento de robots
        for (Robot robot : robots) {
            Store bestStore = findBestStoreForRobot(robot);
            if (bestStore != null) {
                int distance = Math.abs(bestStore.getLocation() - robot.getCurrentLocation());
                int profit = bestStore.getCurrentTenges() - distance;
                if (profit > 0) {
                    moveRobot(robot.getCurrentLocation(), 
                             bestStore.getLocation() - robot.getCurrentLocation());
                }
            }
        }
    }
    
    /**
     * Reabastece todas las tiendas a sus cantidades originales de tenges
     */
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
        }
        if (isVisible) {
            roadVisualizer.updateAllStores(stores);
        }
    }
    
    /**
     * Retorna todos los robots a sus posiciones iniciales
     */
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.returnToStart();
        }
        if (isVisible) {
            roadVisualizer.updateAllRobots(robots);
        }
    }
    
    /**
     * Reinicia la simulación - reabastece tiendas y retorna robots
     */
    public void reboot() {
        // Reiniciar ganancias de cada robot
        for (Robot robot : robots) {
            robot.resetProfit();
        }
        
        resupplyStores();
        returnRobots();
        totalProfit = 0;
        
        if (isVisible) {
            profitBar.update(totalProfit, maxPossibleProfit);
            roadVisualizer.updateAll(stores, robots);
        }
    }
    
    /**
     * Obtiene la ganancia actual
     * @return Ganancia total actual
     */
    public int profit() {
        return totalProfit;
    }
    
    /**
     * Obtiene array de información de tiendas
     * @return Array de datos de tiendas [ubicación, tenges]
     */
    public int[][] stores() {
        int[][] storeData = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            storeData[i][0] = store.getLocation();
            storeData[i][1] = store.getCurrentTenges();
        }
        return storeData;
    }
    
    /**
     * Obtiene array de información de robots
     * @return Array de datos de robots [ubicación_inicial, ubicación_actual]
     */
    public int[][] robots() {
        int[][] robotData = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            robotData[i][0] = robot.getStartLocation();
            robotData[i][1] = robot.getCurrentLocation();
        }
        return robotData;
    }
    
    /**
     * Obtiene el conteo de tiendas vaciadas
     * @return Array de [ubicación, veces_vaciada] para cada tienda
     */
    public int[][] emptiedStores() {
        int[][] emptiedData = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            emptiedData[i][0] = store.getLocation();
            emptiedData[i][1] = store.getEmptiedCount();
        }
        return emptiedData;
    }
    
    /**
     * Obtiene las ganancias por movimiento de cada robot
     * @return Array de [ubicación, ganancia_movimiento_1, ganancia_movimiento_2, ...]
     */
    public int[][] profitPerMove() {
        int maxMoves = 0;
        for (Robot robot : robots) {
            maxMoves = Math.max(maxMoves, robot.getProfitHistory().size());
        }
        
        int[][] profitData = new int[robots.size()][maxMoves + 1];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            profitData[i][0] = robot.getStartLocation();
            List<Integer> history = robot.getProfitHistory();
            for (int j = 0; j < history.size(); j++) {
                profitData[i][j + 1] = history.get(j);
            }
        }
        return profitData;
    }
    
    /**
     * Hace visible el simulador
     */
    public void makeVisible() {
        isVisible = true;
        canvas.setVisible(true);
        
        // Ahora que el canvas es visible, podemos dibujar
        roadVisualizer.drawRoad();
        roadVisualizer.drawAll(stores, robots);
        profitBar.update(totalProfit, maxPossibleProfit);
    }
    
    /**
     * Hace invisible el simulador
     */
    public void makeInvisible() {
        isVisible = false;
        canvas.setVisible(false);
    }
    
    /**
     * Termina y cierra el simulador
     */
    public void finish() {
        canvas.setVisible(false);
    }
    
    /**
     * Verifica si las operaciones del simulador son válidas
     * @return true si es válido, false en caso contrario
     */
    public boolean ok() {
        return stores != null && robots != null && canvas != null;
    }
    
    // Métodos auxiliares privados
    
    private void processDaySequence() {
        for (Integer[] day : days) {
            if (day[0] == 1) { // Robot
                placeRobot(day[1]);
            } else if (day[0] == 2) { // Tienda
                placeStore(day[1], day[2]);
            }
        }
    }
    
    private Store findBestStoreForRobot(Robot robot) {
        Store bestStore = null;
        int maxProfit = 0;
        
        for (Store store : stores) {
            if (!store.isEmpty()) {
                int distance = Math.abs(store.getLocation() - robot.getCurrentLocation());
                int profit = store.getCurrentTenges() - distance;
                if (profit > maxProfit) {
                    maxProfit = profit;
                    bestStore = store;
                }
            }
        }
        
        return bestStore;
    }
    
    private void updateMaxPossibleProfit() {
        maxPossibleProfit = 0;
        for (Store store : stores) {
            maxPossibleProfit += store.getOriginalTenges();
        }
    }
    
    private Color getNextStoreColor() {
        // Colores para tiendas (sin negro)
        Color[] storeColors = {Color.BLUE, Color.GREEN, Color.ORANGE, Color.MAGENTA, Color.CYAN, Color.RED};
        return storeColors[stores.size() % storeColors.length];
    }
    
    private Color getNextRobotColor() {
        // Colores para robots (sin negro)
        Color[] robotColors = {Color.RED, Color.YELLOW, Color.PINK, Color.GRAY, Color.BLUE, Color.GREEN};
        return robotColors[robots.size() % robotColors.length];
    }
    
    private void updateRobotBlinking() {
        if (robots.isEmpty()) return;
        
        Robot bestRobot = robots.get(0);
        for (Robot robot : robots) {
            if (robot.getTotalProfit() > bestRobot.getTotalProfit()) {
                bestRobot = robot;
            }
        }
        
        for (Robot robot : robots) {
            robot.setBlinking(robot == bestRobot && robot.getTotalProfit() > 0);
        }
    }
    
    private void showMessage(String message) {
        System.out.println("SilkRoad: " + message);
    }
}