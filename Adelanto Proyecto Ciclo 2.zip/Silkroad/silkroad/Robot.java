import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa un robot en la Ruta de Seda
 * Los robots pueden moverse a lo largo de la ruta y recolectar tenges de las tiendas
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class Robot {
    private int startLocation;
    private int currentLocation;
    private int totalProfit;
    private List<Integer> profitHistory;
    private Color color;
    private boolean isBlinking;
    
    /**
     * Constructor para Robot
     * @param startLocation Posición inicial en la ruta
     * @param color Color de visualización para el robot
     */
    public Robot(int startLocation, Color color) {
        this.startLocation = startLocation;
        this.currentLocation = startLocation;
        this.totalProfit = 0;
        this.profitHistory = new ArrayList<>();
        this.color = color;
        this.isBlinking = false;
    }
    
    /**
     * Obtiene la ubicación inicial del robot
     * @return Posición inicial en la ruta
     */
    public int getStartLocation() {
        return startLocation;
    }
    
    /**
     * Obtiene la ubicación actual del robot
     * @return Posición actual en la ruta
     */
    public int getCurrentLocation() {
        return currentLocation;
    }
    
    /**
     * Obtiene la ganancia total del robot
     * @return Ganancia total obtenida por este robot
     */
    public int getTotalProfit() {
        return totalProfit;
    }
    
    /**
     * Obtiene el historial de ganancias del robot
     * @return Lista de ganancias de cada movimiento
     */
    public List<Integer> getProfitHistory() {
        return new ArrayList<>(profitHistory);
    }
    
    /**
     * Obtiene el color de visualización del robot
     * @return Color para representación visual
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Verifica si el robot debe estar parpadeando (mayor ganancia)
     * @return true si el robot debe parpadear
     */
    public boolean isBlinking() {
        return isBlinking;
    }
    
    /**
     * Establece el estado de parpadeo del robot
     * @param blinking true para hacer que el robot parpadee
     */
    public void setBlinking(boolean blinking) {
        this.isBlinking = blinking;
    }
    
    /**
     * Mueve el robot a una nueva ubicación
     * @param newLocation Posición objetivo
     * @param distance Distancia movida (para cálculo de costo)
     */
    public void move(int newLocation, int distance) {
        this.currentLocation = newLocation;
        // El costo de movimiento se maneja en el simulador principal al recolectar de tiendas
    }
    
    /**
     * Añade ganancia de un movimiento
     * @param profit Ganancia obtenida (puede ser negativa)
     */
    public void addProfit(int profit) {
        this.totalProfit += profit;
        this.profitHistory.add(profit);
    }
    
    /**
     * Retorna el robot a la ubicación inicial
     */
    public void returnToStart() {
        this.currentLocation = this.startLocation;
    }
    
    /**
     * Reinicia la ganancia y el historial del robot (para nuevo día)
     */
    public void resetProfit() {
        this.totalProfit = 0;
        this.profitHistory.clear();
    }
    
    /**
     * Representación en string del robot
     * @return Información del robot como string
     */
    @Override
    public String toString() {
        return "Robot[start=" + startLocation + ", current=" + currentLocation + 
               ", profit=" + totalProfit + ", moves=" + profitHistory.size() + "]";
    }
}