import java.awt.*;
import java.awt.geom.*;

/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * 
 * @author
 * @version 1.0
 */
public class Circle {

    public static final double PI = 3.1416;

    private int diameter;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    public Circle() {
        diameter = 30;
        xPosition = 20;
        yPosition = 15;
        color = "blue";
        isVisible = false;
    }

    /**
     * Nuevo constructor con posición y tamaño.
     */
    public Circle(int x, int y, int diameter) {
        this.diameter = diameter;
        this.xPosition = x;
        this.yPosition = y;
        this.color = "blue";
        this.isVisible = false;
    }

    /**
     * Creador que permite crear un círculo con un área específica.
     */
    public Circle(int area) {
        diameter = (int) Math.round(2 * Math.sqrt(area / Math.PI));
        xPosition = 20;
        yPosition = 60;
        color = "blue";
        isVisible = false;
    }

    /**
     * Metodo para sacar area del circulo.
     */
    public double area() {
        double radio = diameter / 2.0;
        return Math.PI * radio * radio;
    }

    /**
     * Metodo "bigger" para aumentar el área del circulo un porcentaje [0..100]
     */
    public void bigger(int percentage) {
        if (percentage < 0 || percentage > 100) {
            System.out.println("El porcentaje debe estar entre 0 y 100.");
            return;
        }
        double factor = Math.sqrt(1 + (percentage / 100.0));
        diameter = (int) Math.round(diameter * factor);
        if (isVisible) {
            draw();
        }
    }

    /**
     * Metodo "shrink" para disminuye su tamaño times veces.
     */
    public void shrink(int times, int area) {
        int count = 0;
        while (count < times && this.area() > area) {
            diameter = diameter / 2;
            count++;
            if (isVisible) {
                draw();
            }
        }
    }

    /**
     * Nuevo metodo que calcula el perímetro/circunferencia del círculo.
     */
    public double perimetro() {
        double radio = diameter / 2.0;
        return 2 * Math.PI * radio;
    }

    public void makeVisible() {
        isVisible = true;
        draw();
    }

    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    private void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                    new Ellipse2D.Double(xPosition, yPosition,
                            diameter, diameter));
            canvas.wait(10);
        }
    }

    private void erase() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }

    public void moveRight() {
        moveHorizontal(20);
    }

    public void moveLeft() {
        moveHorizontal(-20);
    }

    public void moveUp() {
        moveVertical(-20);
    }

    public void moveDown() {
        moveVertical(20);
    }

    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance;
        draw();
    }

    public void moveVertical(int distance) {
        erase();
        yPosition += distance;
        draw();
    }

    public void slowMoveHorizontal(int distance) {
        int delta;
        if (distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }
        for (int i = 0; i < distance; i++) {
            xPosition += delta;
            draw();
        }
    }

    public void slowMoveVertical(int distance) {
        int delta;
        if (distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }
        for (int i = 0; i < distance; i++) {
            yPosition += delta;
            draw();
        }
    }

    public void changeSize(int newDiameter) {
        erase();
        diameter = newDiameter;
        draw();
    }

    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }

    /**
     * Devuelve el Shape asociado (útil en otros visualizadores).
     */
    public Ellipse2D getShape() {
        return new Ellipse2D.Double(xPosition, yPosition, diameter, diameter);
    }
}
