import java.util.*;
import java.awt.Color;

/**
 * Simulador de SilkRoad en el Problem J de ICPC 2024
 * Simula robots que recolectan tenges de tiendas a lo largo de una ruta
 */
public class SilkRoad {
    private int length;
    private Canvas canvas;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private ArrayList<Integer[]> days;
    private int totalProfit;
    private int maxPossibleProfit;
    private boolean isVisible;
    
    // Visualización
    private int cellSize;
    private int startX, startY;
    private List<Point> roadPoints;
    
    // Barra de progreso
    private java.awt.Rectangle backgroundBar;
    private java.awt.Rectangle progressBar;
    private String progressId;
    
    // Para el parpadeo
    private Thread blinkingThread;
    private volatile boolean shouldBlink = false;
    
    /**
     * Constructor para el simulador SilkRoad
     * @param length La longitud de la ruta de seda
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.days = new ArrayList<>();
        this.totalProfit = 0;
        this.maxPossibleProfit = 0;
        this.isVisible = false;
        
        // Inicializar visualización
        this.canvas = new Canvas("Simulador Ruta de Seda", 800, 600, Color.WHITE, true);
        this.cellSize = 20;
        this.startX = 400;
        this.startY = 300;
        this.roadPoints = new ArrayList<>();
        
        // Inicializar barra de progreso
        this.backgroundBar = new java.awt.Rectangle(50, 20, 300, 30);
        this.progressBar = new java.awt.Rectangle(50, 20, 0, 30);
        this.progressId = "progress_" + System.currentTimeMillis();
        
        generateSpiralPoints();
    }
    
    /**
     * Constructor para SilkRoad con secuencia de días del problema
     * @param days Array de datos de días [tipo, ubicación, tenges]
     */
    public SilkRoad(Integer[][] days) {
        this(1000); // Longitud por defecto grande
        this.days = new ArrayList<>(Arrays.asList(days));
        processDaySequence();
    }
    
    /**
     * Coloca una tienda en la ubicación especificada con tenges dados
     * @param location Posición en la ruta
     * @param tenges Cantidad de dinero en la tienda
     */
    public void placeStore(int location, int tenges) {
        if (location < 0 || location > length) {
            showMessage("Ubicación inválida: La tienda debe colocarse dentro de los límites de la ruta (0-" + length + ")");
            return;
        }
        
        // Verificar si la ubicación ya está ocupada por una tienda
        for (Store store : stores) {
            if (store.getLocation() == location) {
                showMessage("Ubicación ya ocupada por una tienda");
                return;
            }
        }
        
        Store newStore = new Store(location, tenges, getNextStoreColor());
        stores.add(newStore);
        updateMaxPossibleProfit();
        
        if (isVisible) {
            drawStore(newStore);
            updateProgressBar();
        }
    }
    
    /**
     * Elimina la tienda en la ubicación especificada
     * @param location Posición de la tienda a eliminar
     */
    public void removeStore(int location) {
        Store toRemove = null;
        for (Store store : stores) {
            if (store.getLocation() == location) {
                toRemove = store;
                break;
            }
        }
        
        if (toRemove == null) {
            showMessage("No se encontró tienda en la ubicación " + location);
            return;
        }
        
        if (isVisible) {
            canvas.erase("store_" + location);
        }
        
        stores.remove(toRemove);
        updateMaxPossibleProfit();
        
        if (isVisible) {
            updateProgressBar();
        }
    }
    
    /**
     * Coloca un robot en la ubicación especificada
     * @param location Posición inicial del robot
     */
    public void placeRobot(int location) {
        if (location < 0 || location > length) {
            showMessage("Ubicación inválida: El robot debe colocarse dentro de los límites de la ruta (0-" + length + ")");
            return;
        }
        
        // Verificar si la ubicación ya está ocupada por la posición inicial de otro robot
        for (Robot robot : robots) {
            if (robot.getStartLocation() == location) {
                showMessage("Ubicación inicial ya ocupada por otro robot");
                return;
            }
        }
        
        Robot newRobot = new Robot(location, getNextRobotColor());
        robots.add(newRobot);
        returnRobots();
        
        if (isVisible) {
            drawRobot(newRobot);
            updateRobotBlinking();
        }
    }
    
    /**
     * Elimina el robot en la ubicación especificada
     * @param location Posición inicial del robot a eliminar
     */
    public void removeRobot(int location) {
        Robot toRemove = null;
        for (Robot robot : robots) {
            if (robot.getStartLocation() == location) {
                toRemove = robot;
                break;
            }
        }
        
        if (toRemove == null) {
            showMessage("No se encontró robot con ubicación inicial " + location);
            return;
        }
        
        if (isVisible) {
            canvas.erase("robot_" + location);
        }
        
        robots.remove(toRemove);
        returnRobots();
        
        if (isVisible) {
            updateRobotBlinking();
        }
    }
    
    /**
     * Mueve un robot a la ubicación y distancia especificadas
     * @param location Ubicación actual del robot
     * @param meters Distancia a mover
     */
    public void moveRobot(int location, int meters) {
        Robot robotToMove = null;
        for (Robot robot : robots) {
            if (robot.getCurrentLocation() == location) {
                robotToMove = robot;
                break;
            }
        }
        
        if (robotToMove == null) {
            showMessage("No se encontró robot en la ubicación " + location);
            return;
        }
        
        int newLocation = location + meters;
        if (newLocation < 0 || newLocation > length) {
            showMessage("El robot no puede moverse fuera de los límites de la ruta");
            return;
        }
        
        robotToMove.move(newLocation, meters);
        
        // Verificar si el robot llegó a una tienda
        Store storeAtLocation = null;
        for (Store store : stores) {
            if (store.getLocation() == newLocation && !store.isEmpty()) {
                storeAtLocation = store;
                break;
            }
        }
        
        if (storeAtLocation != null) {
            int profit = storeAtLocation.getCurrentTenges() - Math.abs(meters);
            robotToMove.addProfit(profit);
            totalProfit += profit;
            
            // Solo vaciar la tienda si la ganancia fue positiva
            if (profit > 0) {
                storeAtLocation.empty();
                storeAtLocation.incrementEmptiedCount();
                
                if (isVisible) {
                    drawStore(storeAtLocation);
                }
            }
        }
        
        if (isVisible) {
            drawRobot(robotToMove);
            updateProgressBar();
            updateRobotBlinking();
        }
    }
    
    /**
     * Mueve los robots automáticamente para maximizar las ganancias
     */
    public void moveRobots() {
        // Implementar algoritmo greedy para el movimiento de robots
        for (Robot robot : robots) {
            Store bestStore = findBestStoreForRobot(robot);
            if (bestStore != null) {
                int distance = Math.abs(bestStore.getLocation() - robot.getCurrentLocation());
                int profit = bestStore.getCurrentTenges() - distance;
                if (profit > 0) {
                    moveRobot(robot.getCurrentLocation(), 
                             bestStore.getLocation() - robot.getCurrentLocation());
                }
            }
        }
    }
    
    /**
     * Reabastece todas las tiendas a sus cantidades originales de tenges
     */
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
        }
        if (isVisible) {
            drawAllStores();
        }
    }
    
    /**
     * Retorna todos los robots a sus posiciones iniciales
     */
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.returnToStart();
        }
        if (isVisible) {
            drawAllRobots();
        }
    }
    
    /**
     * Reinicia la simulación - reabastece tiendas y retorna robots
     */
    public void reboot() {
        // Reiniciar ganancias de cada robot
        for (Robot robot : robots) {
            robot.resetProfit();
        }
        
        resupplyStores();
        returnRobots();
        totalProfit = 0;
        
        if (isVisible) {
            updateProgressBar();
            drawAllStores();
            drawAllRobots();
            updateRobotBlinking();
        }
    }
    
    /**
     * Obtiene la ganancia actual
     * @return Ganancia total actual
     */
    public int profit() {
        return totalProfit;
    }
    
    /**
     * Obtiene array de información de tiendas
     * @return Array de datos de tiendas [ubicación, tenges]
     */
    public int[][] stores() {
        int[][] storeData = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            storeData[i][0] = store.getLocation();
            storeData[i][1] = store.getCurrentTenges();
        }
        return storeData;
    }
    
    /**
     * Obtiene array de información de robots
     * @return Array de datos de robots [ubicación_inicial, ubicación_actual]
     */
    public int[][] robots() {
        int[][] robotData = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            robotData[i][0] = robot.getStartLocation();
            robotData[i][1] = robot.getCurrentLocation();
        }
        return robotData;
    }
    
    /**
     * Obtiene el conteo de tiendas vaciadas
     * @return Array de [ubicación, veces_vaciada] para cada tienda
     */
    public int[][] emptiedStores() {
        int[][] emptiedData = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            emptiedData[i][0] = store.getLocation();
            emptiedData[i][1] = store.getEmptiedCount();
        }
        return emptiedData;
    }
    
    /**
     * Obtiene las ganancias por movimiento de cada robot
     * @return Array de [ubicación, ganancia_movimiento_1, ganancia_movimiento_2, ...]
     */
    public int[][] profitPerMove() {
        int maxMoves = 0;
        for (Robot robot : robots) {
            maxMoves = Math.max(maxMoves, robot.getProfitHistory().size());
        }
        
        int[][] profitData = new int[robots.size()][maxMoves + 1];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            profitData[i][0] = robot.getStartLocation();
            List<Integer> history = robot.getProfitHistory();
            for (int j = 0; j < history.size(); j++) {
                profitData[i][j + 1] = history.get(j);
            }
        }
        return profitData;
    }
    
    /**
     * Hace visible el simulador
     */
    public void makeVisible() {
        isVisible = true;
        canvas.setVisible(true);
        
        // Esperar un momento para que el canvas se inicialice
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // Ignorar
        }
        
        // Ahora refrescar toda la visualización
        refreshDisplay();
    }
    
    /**
     * Hace invisible el simulador
     */
    public void makeInvisible() {
        isVisible = false;
        shouldBlink = false;
        if (blinkingThread != null) {
            blinkingThread.interrupt();
        }
        canvas.setVisible(false);
    }
    
    /**
     * Termina y cierra el simulador
     */
    public void finish() {
        shouldBlink = false;
        if (blinkingThread != null) {
            blinkingThread.interrupt();
        }
        canvas.setVisible(false);
    }
    
    /**
     * Verifica si las operaciones del simulador son válidas
     * @return true si es válido, false en caso contrario
     */
    public boolean ok() {
        return stores != null && robots != null && canvas != null;
    }
    
    // Métodos privados de visualización
    
    /**
     * Genera puntos para la ruta en espiral cuadrada
     */
    private void generateSpiralPoints() {
        roadPoints.clear();
        
        int x = startX;
        int y = startY;
        int direction = 0; // 0=derecha, 1=arriba, 2=izquierda, 3=abajo
        int steps = 1;
        int stepCount = 0;
        int changeCount = 0;
        
        roadPoints.add(new Point(x, y));
        
        for (int i = 1; i < Math.min(length, 1000); i++) {
            // Mover en la dirección actual
            switch (direction) {
                case 0: x += cellSize; break; // derecha
                case 1: y -= cellSize; break; // arriba
                case 2: x -= cellSize; break; // izquierda
                case 3: y += cellSize; break; // abajo
            }
            
            roadPoints.add(new Point(x, y));
            stepCount++;
            
            // Verificar si necesitamos cambiar dirección
            if (stepCount == steps) {
                direction = (direction + 1) % 4;
                stepCount = 0;
                changeCount++;
                
                // Incrementar pasos cada dos cambios de dirección
                if (changeCount % 2 == 0) {
                    steps++;
                }
            }
        }
    }
    
    /**
     * Dibuja la ruta en el canvas
     */
    private void drawRoad() {
        try {
            for (int i = 0; i < roadPoints.size(); i++) {
                Point p = roadPoints.get(i);
                java.awt.Rectangle roadCell = new java.awt.Rectangle(p.x - cellSize/2, p.y - cellSize/2, 
                                                 cellSize, cellSize);
                canvas.draw("road_" + i, "white", roadCell);
                
                // Dibujar borde de la ruta
                java.awt.Rectangle border = new java.awt.Rectangle(p.x - cellSize/2 - 1, p.y - cellSize/2 - 1, 
                                               cellSize + 2, cellSize + 2);
                canvas.draw("road_border_" + i, "black", border);
            }
        } catch (Exception e) {
            // Canvas no está listo para dibujar
        }
    }
    
    /**
     * Dibuja una tienda en el canvas
     */
    private void drawStore(Store store) {
        try {
            Point position = getPositionForLocation(store.getLocation());
            if (position != null) {
                // Limpiar tienda anterior
                canvas.erase("store_" + store.getLocation());
                
                java.awt.Rectangle storeRect = new java.awt.Rectangle(position.x - cellSize/3, 
                                                  position.y - cellSize/3, 
                                                  cellSize*2/3, cellSize*2/3);
                
                String color;
                if (store.isEmpty()) {
                    color = "red"; // Las tiendas vaciadas se ven rojas
                } else {
                    color = colorToString(store.getColor());
                }
                
                canvas.draw("store_" + store.getLocation(), color, storeRect);
            }
        } catch (Exception e) {
            // Canvas no está listo
        }
    }
    
    /**
     * Dibuja un robot en el canvas
     */
    private void drawRobot(Robot robot) {
        try {
            // Limpiar robot anterior
            canvas.erase("robot_" + robot.getStartLocation());
            
            Point position = getPositionForLocation(robot.getCurrentLocation());
            if (position != null) {
                // Crear triángulo para el robot
                int size = cellSize/3;
                int[] xPoints = {position.x - size, position.x, position.x + size};
                int[] yPoints = {position.y + size, position.y - size, position.y + size};
                java.awt.Polygon triangle = new java.awt.Polygon(xPoints, yPoints, 3);
                
                String color;
                if (robot.isBlinking()) {
                    // Simular parpadeo alternando entre colores
                    long time = System.currentTimeMillis();
                    if ((time / 300) % 2 == 0) { // Cambiar cada 300ms
                        color = "yellow";
                    } else {
                        color = colorToString(robot.getColor());
                    }
                } else {
                    color = colorToString(robot.getColor());
                }
                
                canvas.draw("robot_" + robot.getStartLocation(), color, triangle);
                
                // Forzar actualización del canvas
                canvas.wait(10);
            }
        } catch (Exception e) {
            // Canvas no está listo
        }
    }
    
    /**
     * Dibuja todas las tiendas
     */
    private void drawAllStores() {
        for (Store store : stores) {
            drawStore(store);
        }
    }
    
    /**
     * Dibuja todos los robots
     */
    private void drawAllRobots() {
        // Limpiar todos los robots primero
        for (Robot robot : robots) {
            canvas.erase("robot_" + robot.getStartLocation());
        }
        
        // Dibujar todos los robots
        for (Robot robot : robots) {
            drawRobot(robot);
        }
    }
    
    /**
     * Refresca toda la visualización
     */
    private void refreshDisplay() {
        if (isVisible) {
            drawRoad();
            drawAllStores();
            drawAllRobots();
            updateProgressBar();
            updateRobotBlinking();
        }
    }
    
    /**
     * Actualiza la barra de progreso con fondo negro, relleno verde, borde rojo
     */
    private void updateProgressBar() {
        try {
            // Limpiar elementos anteriores de la barra de progreso
            canvas.erase(progressId + "_bg");
            canvas.erase(progressId + "_fill");  
            canvas.erase(progressId + "_border");
            
            // Calcular ancho del progreso
            int progressWidth = 0;
            if (maxPossibleProfit > 0) {
                double ratio = (double) Math.max(0, totalProfit) / maxPossibleProfit;
                progressWidth = (int) (ratio * 300);
                progressWidth = Math.max(0, Math.min(300, progressWidth));
            }
            
            // 1. Dibujar el fondo negro completo
            canvas.draw(progressId + "_bg", "black", backgroundBar);
            
            // 2. Dibujar el progreso verde encima (solo la parte llena)
            if (progressWidth > 0) {
                java.awt.Rectangle progressRect = new java.awt.Rectangle(50, 20, progressWidth, 30);
                canvas.draw(progressId + "_fill", "green", progressRect);
            }
            
            // 3. Dibujar el borde rojo al final
            java.awt.Rectangle topBorder = new java.awt.Rectangle(49, 19, 302, 2);
            java.awt.Rectangle bottomBorder = new java.awt.Rectangle(49, 49, 302, 2);
            java.awt.Rectangle leftBorder = new java.awt.Rectangle(49, 19, 2, 32);
            java.awt.Rectangle rightBorder = new java.awt.Rectangle(349, 19, 2, 32);
            
            canvas.draw(progressId + "_border_top", "red", topBorder);
            canvas.draw(progressId + "_border_bottom", "red", bottomBorder);
            canvas.draw(progressId + "_border_left", "red", leftBorder);
            canvas.draw(progressId + "_border_right", "red", rightBorder);
            
        } catch (Exception e) {
            // Canvas no está listo
        }
    }
    
    // Métodos auxiliares privados
    
    private void processDaySequence() {
        for (Integer[] day : days) {
            if (day[0] == 1) { // Robot
                placeRobot(day[1]);
            } else if (day[0] == 2) { // Tienda
                placeStore(day[1], day[2]);
            }
        }
    }
    
    private Store findBestStoreForRobot(Robot robot) {
        Store bestStore = null;
        int maxProfit = 0;
        
        for (Store store : stores) {
            if (!store.isEmpty()) {
                int distance = Math.abs(store.getLocation() - robot.getCurrentLocation());
                int profit = store.getCurrentTenges() - distance;
                if (profit > maxProfit) {
                    maxProfit = profit;
                    bestStore = store;
                }
            }
        }
        
        return bestStore;
    }
    
    private void updateMaxPossibleProfit() {
        maxPossibleProfit = 0;
        for (Store store : stores) {
            maxPossibleProfit += store.getOriginalTenges();
        }
    }
    
    private Color getNextStoreColor() {
        // Colores para tiendas (azul primero, sin rojo inicial)
        Color[] storeColors = {Color.BLUE, Color.GREEN, Color.MAGENTA, Color.CYAN, Color.ORANGE, Color.RED};
        return storeColors[stores.size() % storeColors.length];
    }
    
    private Color getNextRobotColor() {
        // Colores para robots (rojo primero, sin amarillo inicial)
        Color[] robotColors = {Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.GRAY, Color.YELLOW};
        return robotColors[robots.size() % robotColors.length];
    }
    
    /**
     * Actualiza el parpadeo de robots (el de mayor ganancia)
     */
    private void updateRobotBlinking() {
        if (robots.isEmpty()) return;
        
        // Detener el hilo de parpadeo anterior
        shouldBlink = false;
        if (blinkingThread != null) {
            blinkingThread.interrupt();
        }
        
        // Encontrar robot con mayor ganancia
        Robot bestRobot = null;
        int maxProfit = Integer.MIN_VALUE;
        
        for (Robot robot : robots) {
            if (robot.getTotalProfit() > maxProfit) {
                maxProfit = robot.getTotalProfit();
                bestRobot = robot;
            }
        }
        
        // Establecer parpadeo solo para el robot con mayor ganancia positiva
        for (Robot robot : robots) {
            boolean shouldBlinkRobot = (robot == bestRobot && robot.getTotalProfit() > 0);
            robot.setBlinking(shouldBlinkRobot);
        }
        
        // Si hay robot que debe parpadear, iniciar hilo de parpadeo
        if (bestRobot != null && bestRobot.getTotalProfit() > 0) {
            shouldBlink = true;
            final Robot robotToBlink = bestRobot;
            
            blinkingThread = new Thread(() -> {
                try {
                    while (shouldBlink && isVisible && !Thread.currentThread().isInterrupted()) {
                        if (isVisible) {
                            drawRobot(robotToBlink);
                        }
                        Thread.sleep(300); // Parpadear cada 300ms
                    }
                } catch (InterruptedException e) {
                    // Hilo interrumpido, salir normalmente
                }
            });
            
            blinkingThread.setDaemon(true);
            blinkingThread.start();
        }
        
        // Redibujar todos los robots
        if (isVisible) {
            drawAllRobots();
        }
    }
    
    private Point getPositionForLocation(int location) {
        if (location >= 0 && location < roadPoints.size()) {
            return roadPoints.get(location);
        }
        return null;
    }
    
    private String colorToString(Color color) {
        if (color.equals(Color.RED)) return "red";
        else if (color.equals(Color.BLUE)) return "blue";
        else if (color.equals(Color.GREEN)) return "green";
        else if (color.equals(Color.YELLOW)) return "yellow";
        else if (color.equals(Color.MAGENTA)) return "magenta";
        else if (color.equals(Color.CYAN)) return "cyan";
        else if (color.equals(Color.ORANGE)) return "orange";
        else if (color.equals(Color.GRAY)) return "gray";
        else if (color.equals(Color.BLACK)) return "black";
        else return "blue";
    }
    
    private void showMessage(String message) {
        if (isVisible) {
            System.out.println("SilkRoad: " + message);
        }
    }
    
    /**
     * Clase Point simple para coordenadas
     */
    private class Point {
        public int x, y;
        
        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}