import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas unitarias para el simulador SilkRoad - Ciclo 2
 * Las pruebas deben ejecutarse en modo invisible como se especifica
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class SilkRoadC2Test {
    
    private SilkRoad silkRoad;
    
    @BeforeEach
    public void setUp() {
        silkRoad = new SilkRoad(100);
        // Mantener invisible para las pruebas
    }
    
    /**
     * Prueba creación básica de la ruta de seda
     */
    @Test
    public void shouldCreateSilkRoadWithLength() {
        assertTrue(silkRoad.ok());
        assertEquals(0, silkRoad.profit());
    }
    
    /**
     * Prueba agregar tiendas
     */
    @Test
    public void shouldAddStoreCorrectly() {
        silkRoad.placeStore(10, 50);
        int[][] stores = silkRoad.stores();
        
        assertEquals(1, stores.length);
        assertEquals(10, stores[0][0]); // ubicación
        assertEquals(50, stores[0][1]); // tenges
    }
    
    /**
     * Prueba agregar robots
     */
    @Test
    public void shouldAddRobotCorrectly() {
        silkRoad.placeRobot(5);
        int[][] robots = silkRoad.robots();
        
        assertEquals(1, robots.length);
        assertEquals(5, robots[0][0]); // ubicación inicial
        assertEquals(5, robots[0][1]); // ubicación actual
    }
    
    /**
     * Prueba movimiento de robot y cálculo de ganancias
     */
    @Test
    public void shouldCalculateProfitCorrectly() {
        silkRoad.placeStore(15, 50);
        silkRoad.placeRobot(10);
        
        // Mover robot a tienda (distancia = 5, ganancia = 50 - 5 = 45)
        silkRoad.moveRobot(10, 5);
        
        assertEquals(45, silkRoad.profit());
        
        int[][] robots = silkRoad.robots();
        assertEquals(15, robots[0][1]); // robot se movió a ubicación 15
    }
    
    /**
     * Prueba funcionalidad de reabastecimiento de tiendas
     */
    @Test
    public void shouldResupplyStoresCorrectly() {
        silkRoad.placeStore(20, 100);
        silkRoad.placeRobot(15);
        
        // Mover robot para recolectar de tienda
        silkRoad.moveRobot(15, 5);
        
        // La tienda debería estar vacía ahora
        int[][] stores = silkRoad.stores();
        assertEquals(0, stores[0][1]); // tenges deberían ser 0
        
        // Reabastecer tiendas
        silkRoad.resupplyStores();
        stores = silkRoad.stores();
        assertEquals(100, stores[0][1]); // tenges deberían volver a 100
    }
    
    /**
     * Prueba retorno de robots a posición inicial
     */
    @Test
    public void shouldReturnRobotsToStart() {
        silkRoad.placeRobot(25);
        silkRoad.moveRobot(25, 10);
        
        int[][] robots = silkRoad.robots();
        assertEquals(35, robots[0][1]); // se movió a 35
        
        silkRoad.returnRobots();
        robots = silkRoad.robots();
        assertEquals(25, robots[0][1]); // de vuelta al inicio en 25
    }
    
    /**
     * Prueba funcionalidad de reinicio
     */
    @Test
    public void shouldRebootCorrectly() {
        silkRoad.placeStore(30, 80);
        silkRoad.placeRobot(25);
        silkRoad.moveRobot(25, 5);
        
        assertTrue(silkRoad.profit() > 0);
        
        silkRoad.reboot();
        
        assertEquals(0, silkRoad.profit());
        int[][] robots = silkRoad.robots();
        assertEquals(25, robots[0][1]); // robot de vuelta al inicio
        int[][] stores = silkRoad.stores();
        assertEquals(80, stores[0][1]); // tienda reabastecida
    }
    
    /**
     * Prueba creación con secuencia de días (requisito Ciclo 2)
     */
    @Test
    public void shouldCreateFromDaySequence() {
        Integer[][] days = {
            {1, 20},        // Robot en ubicación 20
            {2, 15, 50},    // Tienda en ubicación 15 con 50 tenges
            {2, 40, 75},    // Tienda en ubicación 40 con 75 tenges
            {1, 50}         // Robot en ubicación 50
        };
        
        SilkRoad testRoad = new SilkRoad(days);
        
        int[][] robots = testRoad.robots();
        int[][] stores = testRoad.stores();
        
        assertEquals(2, robots.length);
        assertEquals(2, stores.length);
        
        assertEquals(20, robots[0][0]); // Primer robot en 20
        assertEquals(50, robots[1][0]); // Segundo robot en 50
        
        assertEquals(15, stores[0][0]); // Primera tienda en 15
        assertEquals(40, stores[1][0]); // Segunda tienda en 40
    }
    
    /**
     * Prueba movimiento automático de robots (requisito Ciclo 2)
     */
    @Test
    public void shouldMoveRobotsAutomatically() {
        silkRoad.placeStore(25, 100);
        silkRoad.placeStore(75, 80);
        silkRoad.placeRobot(20);
        silkRoad.placeRobot(70);
        
        int initialProfit = silkRoad.profit();
        
        silkRoad.moveRobots();
        
        assertTrue(silkRoad.profit() > initialProfit);
    }
    
    /**
     * Prueba seguimiento de tiendas vaciadas (requisito Ciclo 2)
     */
    @Test
    public void shouldTrackEmptiedStores() {
        silkRoad.placeStore(35, 60);
        silkRoad.placeRobot(30);
        
        // Inicialmente ninguna tienda vaciada
        int[][] emptiedStores = silkRoad.emptiedStores();
        assertEquals(0, emptiedStores[0][1]); // veces vaciada = 0
        
        // Mover robot para vaciar tienda
        silkRoad.moveRobot(30, 5);
        emptiedStores = silkRoad.emptiedStores();
        assertEquals(1, emptiedStores[0][1]); // veces vaciada = 1
        
        // Reabastecer y vaciar de nuevo
        silkRoad.resupplyStores();
        silkRoad.returnRobots();
        silkRoad.moveRobot(30, 5);
        emptiedStores = silkRoad.emptiedStores();
        assertEquals(2, emptiedStores[0][1]); // veces vaciada = 2
    }
    
    /**
     * Prueba seguimiento de ganancias por movimiento (requisito Ciclo 2)
     */
    @Test
    public void shouldTrackProfitPerMove() {
        silkRoad.placeStore(45, 70);
        silkRoad.placeStore(85, 90);
        silkRoad.placeRobot(40);
        
        // Hacer múltiples movimientos
        silkRoad.moveRobot(40, 5);  // Ganancia: 70 - 5 = 65
        silkRoad.moveRobot(45, 40); // Mover a segunda tienda, ganancia: 90 - 40 = 50
        
        int[][] profitPerMove = silkRoad.profitPerMove();
        assertEquals(1, profitPerMove.length); // Un robot
        assertEquals(40, profitPerMove[0][0]); // Ubicación inicial del robot
        assertEquals(65, profitPerMove[0][1]); // Ganancia del primer movimiento
        assertEquals(50, profitPerMove[0][2]); // Ganancia del segundo movimiento
    }
    
    /**
     * Prueba que las operaciones inválidas no causen fallos
     */
    @Test
    public void shouldHandleInvalidOperationsGracefully() {
        // Intentar colocar tienda fuera de límites
        silkRoad.placeStore(-1, 50);
        silkRoad.placeStore(200, 50);
        assertEquals(0, silkRoad.stores().length);
        
        // Intentar mover robot inexistente
        silkRoad.moveRobot(99, 5);
        assertEquals(0, silkRoad.profit());
        
        // Intentar eliminar tienda inexistente
        silkRoad.removeStore(50);
        assertTrue(silkRoad.ok()); // Debería seguir siendo válido
    }
    
    /**
     * Prueba escenarios de ganancia negativa
     */
    @Test
    public void shouldHandleNegativeProfitCorrectly() {
        silkRoad.placeStore(90, 10); // Tienda con pocos tenges
        silkRoad.placeRobot(10);
        
        // Mover robot lejos para llegar a tienda (costo > recompensa)
        silkRoad.moveRobot(10, 80); // Costo: 80, Recompensa: 10, Ganancia: -70
        
        assertEquals(-70, silkRoad.profit());
    }
    
    /**
     * Prueba que múltiples robots no interfieren entre sí
     */
    @Test
    public void shouldHandleMultipleRobotsIndependently() {
        silkRoad.placeStore(25, 50);
        silkRoad.placeStore(75, 100);
        silkRoad.placeRobot(20);
        silkRoad.placeRobot(70);
        
        // Mover primer robot
        silkRoad.moveRobot(20, 5); // Ganancia: 45
        
        // Mover segundo robot  
        silkRoad.moveRobot(70, 5); // Ganancia: 95
        
        assertEquals(140, silkRoad.profit()); // Ganancia total
        
        // Verificar que los robots están en ubicaciones diferentes
        int[][] robots = silkRoad.robots();
        assertEquals(25, robots[0][1]); // Primer robot en 25
        assertEquals(75, robots[1][1]); // Segundo robot en 75
    }
}