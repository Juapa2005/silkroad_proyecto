import java.awt.Color;

/**
 * Representa una tienda en la Ruta de Seda
 * Las tiendas pueden contener tenges y ser vaciadas por robots
 * 
 * @author Equipo de Desarrollo SilkRoad
 * @version 2.0
 */
public class Store {
    private int location;
    private int originalTenges;
    private int currentTenges;
    private boolean isEmpty;
    private int emptiedCount;
    private Color color;
    
    /**
     * Constructor para Store
     * @param location Posición en la ruta
     * @param tenges Cantidad inicial de tenges
     * @param color Color de visualización para la tienda
     */
    public Store(int location, int tenges, Color color) {
        this.location = location;
        this.originalTenges = tenges;
        this.currentTenges = tenges;
        this.isEmpty = false;
        this.emptiedCount = 0;
        this.color = color;
    }
    
    /**
     * Obtiene la ubicación de la tienda
     * @return Ubicación en la ruta
     */
    public int getLocation() {
        return location;
    }
    
    /**
     * Obtiene la cantidad original de tenges
     * @return Tenges originales cuando se creó la tienda
     */
    public int getOriginalTenges() {
        return originalTenges;
    }
    
    /**
     * Obtiene la cantidad actual de tenges
     * @return Tenges actuales en la tienda
     */
    public int getCurrentTenges() {
        return currentTenges;
    }
    
    /**
     * Verifica si la tienda está vacía
     * @return true si la tienda no tiene tenges
     */
    public boolean isEmpty() {
        return isEmpty;
    }
    
    /**
     * Obtiene el número de veces que la tienda ha sido vaciada
     * @return Conteo de veces vaciada
     */
    public int getEmptiedCount() {
        return emptiedCount;
    }
    
    /**
     * Obtiene el color de visualización de la tienda
     * @return Color para representación visual
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Vacía la tienda (el robot recolecta todos los tenges)
     */
    public void empty() {
        currentTenges = 0;
        isEmpty = true;
    }
    
    /**
     * Incrementa el conteo de veces que esta tienda ha sido vaciada
     */
    public void incrementEmptiedCount() {
        emptiedCount++;
    }
    
    /**
     * Reabastece la tienda a la cantidad original de tenges
     */
    public void resupply() {
        currentTenges = originalTenges;
        isEmpty = false;
    }
    
    /**
     * Representación en string de la tienda
     * @return Información de la tienda como string
     */
    @Override
    public String toString() {
        return "Store[location=" + location + ", tenges=" + currentTenges + 
               "/" + originalTenges + ", emptied=" + emptiedCount + "x]";
    }
}